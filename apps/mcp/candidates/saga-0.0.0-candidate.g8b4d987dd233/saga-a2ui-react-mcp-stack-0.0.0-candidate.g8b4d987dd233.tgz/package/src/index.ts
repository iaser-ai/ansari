// The React and MCP Apps stack, main entry: an application's own catalog and nothing else. It
// imports nothing from `@saga-a2ui/components`, so an own-catalog application's emitted browser
// bundle holds neither the FaithfulCard nor a Markdown parser. (Its installed tree does include
// them, as declared dependencies of the stack; the card application's entry is `/faithful-card`.)
//
// An application that installs this stack and React writes its view, its catalog and its actions
// against the names below and declares no other SDK or upstream package for them. The list is
// what the qualifying consumers use, no more.
export {
  startA2uiView,
  type RunningA2uiView,
  type StartA2uiViewOptions,
  type ViewHost,
} from './start-a2ui-view.js';
// What a start can fail with and the phase an `onError` callback is told; the card entry shares them.
export {
  StartError,
  StartFailure,
  type ErrorPhase,
  type StartFailureKind,
  type StartMisuse,
} from './start-failure.js';
export type { RunningView } from './running-view.js';
// The conversation a running view hands its actions, and the results of adding a message to it.
export type {
  AppendResult,
  Conversation,
  RequestOutcome,
} from '@saga-a2ui/core/conversation';
// The shapes of the two notifications an application's handlers receive.
export type { ToolInput, ToolResult } from '@saga-a2ui/mcp/view';
// How the reader meets the host (device or desktop), for an application that maps its own tokens.
export { readingProfile, type ReadingProfile } from '@saga-a2ui/mcp/view';
// The authoring surface of an own-catalog application: the layout and its schemas.
export { defineSurface } from '@saga-a2ui/core/protocols/a2ui/v0_9';
export type { SurfaceLayout } from '@saga-a2ui/core/protocols/a2ui/v0_9';
// A2UI's own Zod 3, for surface and catalog schemas. Tool schemas use `zod` 4 directly.
export { z as z3 } from '@saga-a2ui/core/protocols/a2ui/zod3';
/** @deprecated Use `z3`; removed before 1.0. */
export { z } from '@saga-a2ui/core/protocols/a2ui/zod3';
// The catalog an application builds: its components over upstream's component contracts, kept in
// the renderer package's own dependency context.
export {
  Catalog,
  ColumnApi,
  CommonSchemas,
  createComponentImplementation,
  ListApi,
  RowApi,
  type ReactCatalogComponent,
} from '@saga-a2ui/react/a2ui';
// The actions an application attaches to the controls it renders.
export {
  ActionButton,
  ActionButtonEntry,
  createReactActions,
  type ActionButtonActivation,
  type ReactActions,
  type ReactActionsOptions,
} from '@saga-a2ui/react/actions';
// The removable credit, and the host-link seam it uses (`host.links`): no card or Markdown parser.
// Import its stylesheet from `@saga-a2ui/react-mcp-stack/attribution.css`.
export {
  SagaAttribution,
  type SagaAttributionProps,
} from '@saga-a2ui/react/attribution';
export type { HostLinks, LinkOpenOutcome } from '@saga-a2ui/core/host-links';
export { Action, type ActionBinding } from '@saga-a2ui/core/actions';
export type { BoundSurface } from '@saga-a2ui/react/a2ui';
